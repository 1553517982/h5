import os
import sys
import shutil

def XposeApk(apkName):
    os.system("java -jar -Duser.language=en -Dfile.encoding=UTF8 apktool.jar d {} -o {}out ".format(apkName,apkName.replace(".apk","")))

def RePackApk(apkName):
    os.system("java -jar -Duser.language=en -Dfile.encoding=UTF8 apktool.jar b -o {}unsign.apk {}out".format(apkName.replace(".apk",""),apkName.replace(".apk","")))
    shutil.rmtree("{}out".format(apkName.replace(".apk","")))
    
def ResignApk(apkName):
    os.system("jarsigner -verbose -keystore 123456.keystore -storepass 123456 -keypass 123456 -signedjar {}signed.apk {}unsign.apk 123456.keystore".format(apkName.replace(".apk",""),apkName.replace(".apk","")))
    fileName = "{}unsign.apk".format(apkName.replace(".apk",""))
    os.remove(fileName)

def ZipAlign(apkName):
    os.system("zipalign -f -v 4 {}signed.apk {}realease_signed.apk".format(apkName.replace(".apk",""),apkName.replace(".apk","")))
    fileName = "{}signed.apk".format(apkName.replace(".apk",""))
    os.remove(fileName)


if (__name__=="__main__"):
    apkName = sys.argv[1]
    if apkName==None:
        print "Apk file is Empty"
    else:
        print("=======UnCompressApk===========")
        XposeApk(apkName)
        print("=======ReCompressApk===========")
        RePackApk(apkName)
        print("=======SignCompressApk===========")
        ResignApk(apkName)
        print("=======AlignCompressApk===========")
        ZipAlign(apkName)
        print("=======Finish===========")
    os.system("pause")
