# -*- coding: cp936 -*-
import hashlib
import os

def GetFileMd5(filename):
    if not os.path.isfile(filename):
        return
    myhash = hashlib.md5()
    f = file(filename, 'rb')
    b = f.read()
    myhash.update(b)
    f.close()
    return myhash.hexdigest()


def Compare(maindir,subdir):
    for root, dirs, files in os.walk(maindir, topdown=False):
            for i in files:
                files_name = os.path.join(root, i)
                oringinMd5 = GetFileMd5(files_name)
                subMD5 = GetFileMd5(files_name.replace(maindir,subdir,1))
                if not oringinMd5==subMD5:
                    print files_name
            

Compare("main","newsub")
